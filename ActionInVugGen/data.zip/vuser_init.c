/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_url("index.htm", 
		"URL=http://localhost:1080/WebTours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.google-analytics.com/analytics.js", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("SEARCH_SAMESITE=CgQIh5QB; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:KVI0EvnHfUPrWDYz1PKeAQMv_ymNznqGns9iArYNJHvRQ3w-yZph3dGnQc4Y6uBIj1KnBNwxvYKEpPt5KIGgwPMtT0pRHA:n-Wx11XcnyqfWBuO; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AVQQ_LB55EQk2_uGRSoTpW8oos1RvK8NRs_PGLIo-cY9YhVuRR0tGSFS4Cg; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=AhCg5F0itQW_aOraaivnje7BxLsTPsC-YA2lvVCRxnMeBXfv8crqBUPz_ufIvJk2OWBzvZMwnZLO7hEjixnKHAw896YxOYvErWp-cWMwVDQ0STvneE1292NXtFTY8HItinEd_tZQmkQIJPhIrOPcKoyAkz-Y-JyiFYmVlwJWackHnmUVzSmJ3ENUSE5wx-PMIdBchXCBLi-AWzEbndK4SOE; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_custom_request("v1_GetModels", 
		"URL=https://optimizationguide-pa.googleapis.com/v1_GetModels?key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\nl\\x08\\x08\\x10\\x88\\xB8\\xC0\\xA7\\x880 \\x082_\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.PageEntitiesModelMetadata\\x12\\x02\\x08\\x0B\\x18\\x06*\\x05en-US", 
		LAST);

	web_url("crx", 
		"URL=https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=101.0.4951.67&lang=en-US&acceptformat=crx3&x=id%3Diikflkcanblccfahdhdonehdalibjnif%26v%3D0.0.0.0%26installedby%3Dexternal%26uc%26brand%3DCHBF%26ping%3Dr%253D117%2526e%253D1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:Py6UbovpAMzW-sGeEmlpfrCUsE8DJ3ASQsAQFlCOp4Q&cup2hreq=34e2013b966eb3c77e7628b114b076475f9837e53c0ac51e1d0bf405c00bd919", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"external\",\"packages\":{\"package\":[{\"fp\":\"1.1f57dab48a51560b9890c8ccd9a26178e70a9b48f209d1ff670e71be6de0df62\"}]},\"ping\":{\"ping_freshness\":\"{bb797e68-fafc-45cc-8b91-db4defe89988}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"1.42.0\"},{\"appid\":\"mbopgmdnpcbohhpnfglgohlbhfongabi\",\""
		"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"internal\",\"packages\":{\"package\":[{\"fp\":\"1.f6e46eb762670dd2d6cd64d110dedd7e393d6678f89bcbd9dd81f37da48269b2\"}]},\"ping\":{\"ping_freshness\":\"{155af9ce-c07f-4a44-a07d-d616dd1b1011}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"5.3.0\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\""
		"{fe9c8ac7-0f53-48d4-8143-8014e75c9877}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":8,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22000.675\"},\"prodversion\":\"101.0.4951.67\",\"protocol\":\"3.1\",\"requestid\":\""
		"{a3e49c9e-0019-4c60-baa0-50b170f5b897}\",\"sessionid\":\"{ad0816cc-d496-4d5a-b0eb-67eb3d1dd2c1}\",\"updaterversion\":\"101.0.4951.67\"}}", 
		EXTRARES, 
		"Url=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=101", "Referer=", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvMTAxLjAuNDk1MS42NxIXCU35IjnBRbgwEgUN541ADhIFDc5BTHoYq6nKAQ==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(27);

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:4hYOaw5m_EDJ4Z3i5Uqw1Gpr6DEkdH0hkx5lkxo66D0&cup2hreq=87efa19cf467737f4cd41e168e70b8f52f80881f38646ab41e504ab2041b0fcd", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{31946b91-412e-484e-acbb-af7ba9626030}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"4.10.2449.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{fcbd7b89-06fe-45b7-bc9b-4947055a142d}"
		"\",\"rd\":5608},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{b9776a30-0c61-4885-b0ea-bd4eed61dc52}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\""
		"CHBF\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.75c0917aea02e762102b43e49839262173b6c531e85d03459493d680213755b5\"}]},\"ping\":{\"ping_freshness\":\"{a8f78df3-f1a1-4dc1-adf7-b16415513e64}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"20220409.440702358\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"CHBF\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\""
		"packages\":{\"package\":[{\"fp\":\"1.541e2f6ec39a279b17534740999da1445cf25bae38a2c0d236e2334ca9dff93e\"}]},\"ping\":{\"ping_freshness\":\"{900dba5f-dbbf-41e6-ae56-8ac1b92242e6}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"329\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CHBF\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54AndUp\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.53b83738fad69a9f3db36848834a1d5003880033cae857eadfc37d3802dfcb8c\"}]}"
		",\"ping\":{\"ping_freshness\":\"{bfba6117-6b4e-49eb-ad09-8dd94a651ba5}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"9.35.0\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"CHBF\",\"cohort\":\"1:v3l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.42cd451be050ab9d111953a11792f2d55927b63b199199e2e661624a12d293c1\"}]},\"ping\":{\"ping_freshness\":\"{f5bb18c7-606d-438c-a810-19997f65d2bd}\",\"rd\":5608},\"updatecheck\":{},\""
		"version\":\"2022.5.10.14\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CHBF\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{12198744-e5da-4b6e-810d-51feaff9b67c}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"CHBF\",\"cohort\":\"1:cux:\""
		",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.2c15227a2823f31c7f3728e85a39bd87040d30562f3fa8d1c6faeb20f93e3cc8\"}]},\"ping\":{\"ping_freshness\":\"{aba21716-d613-4164-9120-6a3e58daf497}\",\"rd\":5608},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"50\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CHBF\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{"
		"\"fp\":\"1.530fffe10c07bad64e71aa89db197e13bfd6a0174e010fcf8e8ed90afca97327\"}]},\"ping\":{\"ping_freshness\":\"{fccbf2d8-619b-4daf-b4df-81d61fd5dd66}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"7328\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ab8d70a60ce0fba1355fad4edab88fd4d1bccc566b230998180183d1d776992b\"}]},\"ping\":{\"ping_freshness\":\"{69cb1d9d-70f1-49d3-9dc0-ca1ccccbd474}\",\"rd\":5608"
		"},\"updatecheck\":{},\"version\":\"1.0.0.13\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"CHBF\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.db60fc5d4ab81e28fe58d82f3ad26622c4ca4cade28e2b636068ac91ca62224d\"}]},\"ping\":{\"ping_freshness\":\"{06d52d59-2d06-4eeb-8826-191ff4f1c013}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"1.0.7.1642025427\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\""
		"brand\":\"CHBF\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{f4c0a2db-ec92-4e30-9199-8ecd4cca92b7}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"CHBF\",\"cohort\":\"1:qe3:\",\"cohorthint\":\"Canary\",\"cohortname\":\"Stable\",\""
		"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.e576811650ec2102a3fb16bdb8ff791659558df8f10a6f45bee335c326de72ae\"}]},\"ping\":{\"ping_freshness\":\"{086adacc-8535-4f5e-9dcc-93476e0dd7fc}\",\"rd\":5608},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"101.283.200\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"CHBF\",\"cohort\":\"1:zkl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.f0807b94ce55989abafd76b13b77583b26dfeae3251c7af920a23a2e5873e6fa\"}]},\"ping\":{\"ping_freshness\":\"{701f9a44-32ca-4b28-ab94-c10088437d0b}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"250\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"CHBF\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.8e789958fbb7e07e8f430bde1f47bab6cf3e06504ff86877130d6a61aafaf39d\"}]},\"ping\":{\"ping_freshness\":\""
		"{bbc40a86-8bb1-42cc-9b0c-ec9a78c6da9b}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"2813\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"CHBF\",\"cohort\":\"1:ut9:15af@0.01\",\"cohorthint\":\"M80AndAbove\",\"cohortname\":\"M80AndAbove\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.03c5ff8ab55dca6e912ba078648dd6e6c36da634cf82705b2bfacfcb36796a83\"}]},\"ping\":{\"ping_freshness\":\"{f290e150-3b9e-4d31-a296-4549130fa487}\",\"rd\":5608},\"updatecheck\":{},\"version\":\""
		"2022.4.25.1142\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"CHBF\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.7dab25b845a4241583392b20e9c99f17a8fbe88443aa2b17a4cc8ed7e91d7713\"}]},\"ping\":{\"ping_freshness\":\"{66c6cb32-31f7-4214-aeb7-d0a0752745dd}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"103.0.5054.0\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"brand\":\"CHBF\",\"cohort\":\"1:z9x:"
		"\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.0c24e9bd976adffa987e08fc54dc0950c84cf18f9cdb4c5caabc6acf24887c4f\"}]},\"ping\":{\"ping_freshness\":\"{4aec783a-cb2c-4151-8687-060cef890df9}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"20220505\"},{\"appid\":\"pdafiollngonhoadbmdoemagnfpdphbe\",\"brand\":\"CHBF\",\"cohort\":\"1:vz3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.54b93e249d02a0f9061e8f70866d4668a0260db9ae43483810ab78f97f3eaa2a\"}]},\"ping\":{\"ping_freshness\":\"{bb5b8488-e859-4913-9ed6-e1ab5a0b3500}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"2021.8.17.1300\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"CHBF\",\"cohort\":\"1:zor:154x@0.01\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c5d1f68a61e1a2ea56b08431b1e9de8bca675e76bed24772447af68d35436d50\"}]},\"ping\":{\""
		"ping_freshness\":\"{d6ade474-1e19-41df-942a-b24631c72662}\",\"rd\":5608},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"27.8\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"CHBF\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\"{ce3ac29b-c680-4131-a6be-f852defdb65b}\",\"rd\":5608},\"updatecheck\":{},"
		"\"version\":\"1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"CHBF\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{80a2a963-fc91-4238-ac75-3e48dbaab246}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"_internal_experimental_sets\":\"false\",\"_v2_format_plz\":\"true\",\"appid\":"
		"\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"CHBF\",\"cohort\":\"1:z1x:\",\"cohorthint\":\"General release\",\"cohortname\":\"V2 General release\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c51d23bc0653142853b0d9dc8ba00f504aaae8a2a5b290e539b8790d88c0dcbe\"}]},\"ping\":{\"ping_freshness\":\"{9f4894ec-c72e-4fae-a519-3ff657278c78}\",\"rd\":5608},\"updatecheck\":{},\"version\":\"2022.2.15.1\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory"
		"\":8,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22000.675\"},\"prodversion\":\"101.0.4951.67\",\"protocol\":\"3.1\",\"requestid\":\"{983ad92e-7b9b-4235-ad3e-0c3908fdcb73}\",\"sessionid\":\"{d9ae51a6-6100-4291-91bc-c7d02eae224a}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\""
		"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.132\"},\"updaterversion\":\"101.0.4951.67\"}}", 
		LAST);

	lr_think_time(4);

	web_url("plugins_win.json", 
		"URL=https://www.gstatic.com/chrome/config/plugins_3/plugins_win.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(15);

	web_custom_request("json_3", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"CHBF\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"event\":[{\"download_time_ms\":20355,\"downloaded\":46672,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"330\",\"previousversion\":\"329\",\"total\":46672,\"url\":\"http://edgedl.me.gvt1.com/edgedl/release2/"
		"chrome_component/lcjt7tz4ujwbgfcvzeucz3xjnm_330/lmelglejhemejginpboagddgdfbepgmp_330_all_ZZ_dozv6ie4vfcjgxyrheejlfmwmi.crx3\"},{\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.bdd5297db8e80ac00d6b928cac181cc52fdf068767fedf0c79c0147a8b5d33ec\",\"nextversion\":\"330\",\"previousfp\":\"1.541e2f6ec39a279b17534740999da1445cf25bae38a2c0d236e2334ca9dff93e\",\"previousversion\":\"329\"}],\"packages\":{\"package\":[{\"fp\":\"1.bdd5297db8e80ac00d6b928cac181cc52fdf068767fedf0c79c0147a8b5d33ec\"}]},\""
		"version\":\"330\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":8,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22000.675\"},\"prodversion\":\"101.0.4951.67\",\"protocol\":\"3.1\",\"requestid\":\"{9c68f97b-ebbe-4bc8-934b-706de7cf419a}\",\"sessionid\":\""
		"{d9ae51a6-6100-4291-91bc-c7d02eae224a}\",\"updaterversion\":\"101.0.4951.67\"}}", 
		LAST);

	lr_think_time(31);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=133879.091373026ziiztAfpHzcftVDViptDtfHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=beans", ENDITEM, 
		"Name=login.x", "Value=47", ENDITEM, 
		"Name=login.y", "Value=12", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINMTAxLjAuNDk1MS42NxopCAUQARobCg0IBRAGGAEiAzAwMTABEOzmDRoCGAhWHZz3IgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARD01goaAhgIjTDzViIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQwZULGgIYCJggYWEiBCABIAIoARonCAEQARoZCg0IARAGGAEiAzAwMTADEBQaAhgIseeQLSIEIAEgAigDGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ_ScaAhgIXbWjNSIEIAEgAigEGigIDxABGhoKDQgPEAYYASIDMDAxMAEQ03EaAhgIbIQ3OiIEIAEgAigBGicIChAIGhkKDQgKEAgYASIDMDAxMAEQBxoCGAiVNYrTIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAgGgIYCCdzheIiBCABIAIoARooCAgQARoaCg"
		"0ICBAGGAEiAzAwMTABELcPGgIYCL9OimQiBCABIAIoARopCA0QARobCg0IDRAGGAEiAzAwMTABELa6ARoCGAhtzXyhIgQgASACKAEaKQgDEAEaGwoNCAMQBhgBIgMwMDEwARCyogoaAhgIf_RxZiIEIAEgAigBGikIDhABGhsKDQgOEAYYASIDMDAxMAEQ07MGGgIYCK_DKPIiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABENERGgIYCHY2nO0iBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(44);

	web_submit_form("login.pl_2", 
		"Snapshot=t10.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		LAST);

	return 0;
}
